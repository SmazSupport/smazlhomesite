document.addEventListener("DOMContentLoaded", () => {
  // Check stored preferences and navigate if set
  chrome.storage.local.get(
    ["autoLoadFuelReport", "autoLoadStickReadingReport"],
    (result) => {
      if (result.autoLoadFuelReport) {
        window.location.href = "fuel_report.html";
      } else if (result.autoLoadStickReadingReport) {
        window.location.href = "stick_reading_report.html";
      }
    }
  );

  // Set up button event listeners
  document.getElementById("fuelReportButton").addEventListener("click", () => {
    navigateTo("fuel_report.html");
  });

  document
    .getElementById("stickReadingReportButton")
    .addEventListener("click", () => {
      navigateTo("stick_reading_report.html");
    });
});

function navigateTo(page) {
  window.location.href = page;
}
