// Listening for messages from the popup script.
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  console.log("Message received in content script:", request);

  if (request.action === "fillForm") {
    processFillFormRequest(request, sendResponse);
    return true; // Indicate that response will be sent asynchronously
  } else {
    sendResponse({ type: "error", message: "Unrecognized action." });
    return true; // Indicate async response for consistency
  }
});

function processFillFormRequest(request, sendResponse) {
  try {
    markRelevantInputs();
    let updateMessages = updateFormWithJsonData(request.data);

    // Add Network Revenue value if present in storage
    chrome.storage.local.get(
      ["networkRevenue", "fuelDiscounts"],
      function (result) {
        if (result.networkRevenue !== undefined) {
          const networkRevenue = result.networkRevenue;
          console.log(`Network Revenue retrieved: ${networkRevenue}`);

          const { success, message, status } =
            fillNetworkRevenue(networkRevenue);
          if (!success) {
            console.error(message);
            updateMessages.creditCardMessages = [message];
            if (status === "tolerance") {
              updateMessages.creditCardMessages.unshift(
                "Tolerance issues detected for Credit Cards."
              );
            }
          }
        } else {
          console.error("Network Revenue not found in local storage");
          updateMessages.creditCardMessages = [
            "Network Revenue not found in local storage",
          ];
        }

        // Add Fuel Discounts value if present in storage
        if (result.fuelDiscounts !== undefined) {
          const fuelDiscounts = result.fuelDiscounts;
          console.log(`Fuel Discounts retrieved: ${fuelDiscounts}`);

          const { success, message, status } = fillFuelDiscounts(fuelDiscounts);
          if (!success) {
            console.error(message);
            updateMessages.discountMessages = [message];
            if (status === "tolerance") {
              updateMessages.discountMessages.unshift(
                "Tolerance issues detected for Total Discounts."
              );
            }
          }
        } else {
          console.error("Fuel Discounts not found in local storage");
          updateMessages.discountMessages = [
            "Fuel Discounts not found in local storage",
          ];
        }

        finalizeResponse(updateMessages, sendResponse);
      }
    );
  } catch (error) {
    sendResponse({ type: "error", message: error.toString() });
  }
}

function finalizeResponse(updateResults, sendResponse) {
  const {
    messages,
    summary,
    creditCardMessages = [],
    discountMessages = [],
  } = updateResults;

  const summaryMessage = `
    <h3>Summary</h3>
    <p>Total Fields Processed: ${summary.processedCount}</p>
    <p>Successfully Updated: ${summary.successCount}</p>
    <p>Tolerance Issues: ${summary.toleranceCount}</p>
    <p>Missing Data from PDF: ${summary.missingCount}</p>
    <p>Missing Form Fields: ${summary.pendingCount}</p>
  `;

  const detailedMessages = messages.map((msg) => `<li>${msg}</li>`).join("");

  const creditCardHtml = creditCardMessages
    .map((msg) => `<li>${msg}</li>`)
    .join("");

  const discountHtml = discountMessages
    .map((msg) => `<li>${msg}</li>`)
    .join("");

  const reportHtml = `
    ${
      creditCardHtml
        ? `<h3>Credit Card Tolerance Issues</h3><ul>${creditCardHtml}</ul>`
        : ""
    }
    ${
      discountHtml
        ? `<h3>Total Discount Tolerance Issues</h3><ul>${discountHtml}</ul>`
        : ""
    }
    ${summaryMessage}
    <h3>Details</h3>
    <ul>
      ${detailedMessages}
    </ul>
  `;

  console.log("Sending response back to popup:", {
    type:
      messages.length > 0 ||
      creditCardMessages.length > 0 ||
      discountMessages.length > 0
        ? "warning"
        : "success",
    message: reportHtml,
  });

  sendResponse({
    type:
      messages.length > 0 ||
      creditCardMessages.length > 0 ||
      discountMessages.length > 0
        ? "warning"
        : "success",
    message: reportHtml,
  });
}

function markRelevantInputs() {
  const inputs = [
    ...document.querySelectorAll(
      'input[name="FuelingPositionProductReading.insideDollarReadingNow"]'
    ),
    ...document.querySelectorAll(
      'input[name="FuelingPositionProductReading.insideDollarReadingLast"]'
    ),
    ...document.querySelectorAll(
      'input[name="FuelingPositionProductReading.insideGallonReadingNow"]'
    ),
    ...document.querySelectorAll(
      'input[name="FuelingPositionProductReading.insideGallonReadingLast"]'
    ),
  ];

  console.log(`Found ${inputs.length} inputs to mark.`);
  inputs.forEach((input) => {
    input.dataset.pending = "true"; // Add the data-pending attribute
    highlightInput(input, null, "pending"); // Apply pending update highlight
    console.log(`Marking input as pending: ${input.name}`);
  });
}

function updateFormWithJsonData(jsonData) {
  let pdfErrors = {};
  let formErrors = {};
  let processedCount = 0;
  let successCount = 0;
  let toleranceCount = 0;
  let missingCount = 0;
  let pendingCount = 0;

  jsonData.forEach((entry) => {
    let grade = mapGradeNameToHtmlForm(entry["Grade Name"]);
    let fuelPositionID = findFuelPositionIdByNumber(entry["Fueling Position"]);
    let pdfPosition = entry["Fueling Position"];

    if (fuelPositionID && grade) {
      let updateResults = [
        fillDollarNowByPositionID(fuelPositionID, grade, entry["Close Money"]),
        fillGallonsNowByPositionID(
          fuelPositionID,
          grade,
          entry["Close Volume"]
        ),
        fillDollarLastByPositionID(fuelPositionID, grade, entry["Open Money"]),
        fillGallonsLastByPositionID(
          fuelPositionID,
          grade,
          entry["Open Volume"]
        ),
      ];

      updateResults.forEach((result) => {
        processedCount++;
        if (result.success) {
          successCount++;
        } else {
          if (result.status === "tolerance") {
            toleranceCount++;
          } else if (result.status === "missing") {
            missingCount++;
          }
          formErrors[fuelPositionID] = formErrors[fuelPositionID] || [];
          formErrors[fuelPositionID].push(result.message);
        }
      });
    } else {
      pdfErrors[pdfPosition] = pdfErrors[pdfPosition] || [];
      pdfErrors[pdfPosition].push(
        `Fuel Position ${pdfPosition} (${grade}) information from PDF not used.`
      );
      missingCount++;
    }
  });

  // Add pending fields to the summary
  const pendingFieldsReport = reportPendingFields();
  pendingCount = pendingFieldsReport.count;
  let messages = generateGroupedMessages(pdfErrors, "Missing Data from PDF");
  messages = messages.concat(
    generateGroupedMessages(formErrors, "Form Errors")
  );
  messages = messages.concat(pendingFieldsReport.messages);

  return {
    messages,
    summary: {
      processedCount,
      successCount,
      toleranceCount,
      missingCount,
      pendingCount,
    },
  };
}

function generateGroupedMessages(errorGroups, groupTitle) {
  let messages = [];
  for (let position in errorGroups) {
    if (errorGroups[position].length > 0) {
      messages.push(`${groupTitle} for Fuel Position ${position}:`);
      errorGroups[position].forEach((msg) => messages.push(`- ${msg}`));
    }
  }
  return messages;
}

function reportPendingFields() {
  const messages = [];
  const dollarInputs = document.querySelectorAll(
    'input[name="FuelingPositionProductReading.insideDollarReadingNow"], input[name="FuelingPositionProductReading.insideDollarReadingLast"]'
  );
  const gallonInputs = document.querySelectorAll(
    'input[name="FuelingPositionProductReading.insideGallonReadingNow"], input[name="FuelingPositionProductReading.insideGallonReadingLast"]'
  );

  const allInputs = [...dollarInputs, ...gallonInputs];

  let pendingDollarNowCount = 0;
  let pendingDollarLastCount = 0;
  let pendingGallonNowCount = 0;
  let pendingGallonLastCount = 0;
  let pendingCount = 0;

  allInputs.forEach((input) => {
    if (input.dataset.pending === "true") {
      const fieldName = input.getAttribute("name");

      if (
        fieldName === "FuelingPositionProductReading.insideDollarReadingNow"
      ) {
        pendingDollarNowCount++;
      } else if (
        fieldName === "FuelingPositionProductReading.insideDollarReadingLast"
      ) {
        pendingDollarLastCount++;
      } else if (
        fieldName === "FuelingPositionProductReading.insideGallonReadingNow"
      ) {
        pendingGallonNowCount++;
      } else if (
        fieldName === "FuelingPositionProductReading.insideGallonReadingLast"
      ) {
        pendingGallonLastCount++;
      }
      pendingCount++;
    }
  });

  if (pendingDollarNowCount > 0) {
    messages.push(`${pendingDollarNowCount} Dollar Now fields not filled in`);
  }
  if (pendingDollarLastCount > 0) {
    messages.push(`${pendingDollarLastCount} Dollar Last fields not filled in`);
  }
  if (pendingGallonNowCount > 0) {
    messages.push(`${pendingGallonNowCount} Gallon Now fields not filled in`);
  }
  if (pendingGallonLastCount > 0) {
    messages.push(`${pendingGallonLastCount} Gallon Last fields not filled in`);
  }

  if (pendingCount > 0) {
    messages.push(`\nTotal fields on the form not filled in: ${pendingCount}`);
  }

  console.log(`Total Report Fields Missing: ${pendingCount}`);
  return { messages, count: pendingCount };
}

function getGradeMapping() {
  return {
    REGULAR: "Unleaded",
    UNLEADED: "Unleaded",
    REGULAR2: "Unleaded",
    REGULAR1: "Unleaded",
    "PLUS-EXTRA": "Plus",
    PLUS: "Plus",
    PLUS2: "Plus",
    PLUS1: "Plus",
    "MID-GRADE": "Plus",
    "SUPREME-+": "Super",
    SUPER: "Super",
    SUPER1: "Super",
    SUPER2: "Super",
    PREMIUM: "Super",
    PREMIUM1: "Super",
    PREMIUM2: "Super",
    VPOWER: "Super",
    "DIESEL 1": "Diesel",
    DIESEL: "Diesel",
    TOTAL: "Ignore",
  };
}

function mapGradeNameToHtmlForm(gradeNameFromJson) {
  const gradeMap = getGradeMapping();
  return gradeMap[gradeNameFromJson.toUpperCase()] || gradeNameFromJson;
}

function findFuelPositionIdByNumber(fuelPositionNumber) {
  const fuelPositionSpans = document.querySelectorAll("span.boldTextStyle");
  const pattern = new RegExp(
    `Fueling\\s*Position\\s*${fuelPositionNumber}`,
    "i"
  );

  for (let span of fuelPositionSpans) {
    const normalizedText = span.textContent.replace(/\s+/g, " ").trim();
    if (pattern.test(normalizedText)) {
      const fuelPositionInput = span
        .closest("td")
        .querySelector(
          'input[name="FuelingPositionReading.fuelingPositionID"]'
        );
      if (fuelPositionInput) {
        return fuelPositionInput.value;
      }
    }
  }
  return null;
}

function fillGallonsNowByPositionID(fuelPositionID, grade, newGallonValue) {
  return fillInputByPositionID(
    fuelPositionID,
    grade,
    newGallonValue,
    "FuelingPositionProductReading.insideGallonReadingNow"
  );
}

function fillDollarNowByPositionID(fuelPositionID, grade, newValue) {
  return fillInputByPositionID(
    fuelPositionID,
    grade,
    newValue,
    "FuelingPositionProductReading.insideDollarReadingNow"
  );
}

function fillDollarLastByPositionID(fuelPositionID, grade, newValue) {
  return fillInputByPositionID(
    fuelPositionID,
    grade,
    newValue,
    "FuelingPositionProductReading.insideDollarReadingLast",
    true
  );
}

function fillGallonsLastByPositionID(fuelPositionID, grade, newGallonValue) {
  return fillInputByPositionID(
    fuelPositionID,
    grade,
    newGallonValue,
    "FuelingPositionProductReading.insideGallonReadingLast",
    true
  );
}

function fillInputByPositionID(
  fuelPositionID,
  grade,
  newValue,
  inputName,
  checkTolerance = false
) {
  const matchingGradeInput = findMatchingGradeInput(fuelPositionID, grade);

  const fieldNameMap = {
    "FuelingPositionProductReading.insideDollarReadingNow": "Dollars Now",
    "FuelingPositionProductReading.insideDollarReadingLast": "Dollars Last",
    "FuelingPositionProductReading.insideGallonReadingNow": "Gallons Now",
    "FuelingPositionProductReading.insideGallonReadingLast": "Gallons Last",
  };

  const toleranceMap = {
    "FuelingPositionProductReading.insideDollarReadingLast": 0.01,
    "FuelingPositionProductReading.insideGallonReadingLast": 0.01,
  };

  if (matchingGradeInput) {
    const targetInput = matchingGradeInput
      .closest("tr")
      ?.querySelector(`input[name="${inputName}"]`);

    if (targetInput) {
      const oldValue = parseFloat(targetInput.value.replace(/[\$,]/g, "")) || 0;
      targetInput.value = newValue;

      const tolerance = toleranceMap[inputName] || 0.0;

      if (checkTolerance && !isWithinTolerance(oldValue, newValue, tolerance)) {
        highlightInput(targetInput, oldValue, "tolerance");
        const userFriendlyName = fieldNameMap[inputName] || inputName;
        return {
          success: false,
          status: "tolerance",
          message: `Tolerance off for ${userFriendlyName} at Fuel Position ${fuelPositionID}, Grade ${grade}`,
        };
      }

      highlightInput(targetInput, oldValue, "success");
      return { success: true, status: "success" };
    } else {
      return {
        success: false,
        status: "missing",
        message: `Failed to find matching input for ${inputName} at Fuel Position ${fuelPositionID}, Grade ${grade}`,
      };
    }
  } else {
    return {
      success: false,
      status: "missing",
      message: `Failed to find matching grade input for Fuel Position ${fuelPositionID}, Grade ${grade}`,
    };
  }
}

function findMatchingGradeInput(fuelPositionID, grade) {
  const gradeInputs = Array.from(
    document.querySelectorAll(
      'input[name="FuelingPositionProductReading.fuelingPositionID"]'
    )
  );
  return gradeInputs.find(
    (input) =>
      input.value == fuelPositionID &&
      input
        .closest("tr")
        .querySelector('span[onclick*="toggleTest"]')
        .textContent.trim() === grade
  );
}

function highlightInput(inputElement, oldValue, status) {
  if (oldValue !== undefined) {
    inputElement.title = `Old value: ${oldValue}`;
  }
  switch (status) {
    case "pending":
      inputElement.style.backgroundColor = "lightyellow";
      inputElement.dataset.pending = "true";
      break;
    case "success":
      inputElement.style.backgroundColor = "lightgreen";
      inputElement.dataset.pending = "false";
      break;
    case "tolerance":
      inputElement.style.backgroundColor = "orange";
      inputElement.dataset.pending = "false";
      break;
    case "missing":
      inputElement.style.backgroundColor = "red";
      inputElement.dataset.pending = "false";
      break;
    default:
      inputElement.style.backgroundColor = "";
      inputElement.dataset.pending = "false";
  }
}

function fillNetworkRevenue(networkRevenue) {
  // Locate the table row that contains the "Credit Cards" field
  const creditCardRow = Array.from(
    document.querySelectorAll("td.boldTextStyle")
  )
    .find((td) => td.textContent.trim() === "Credit Cards")
    ?.closest("tr");

  if (creditCardRow) {
    // Find the input field within this row
    const totalInput = creditCardRow.querySelector(
      'input[name="FuelReportFieldReading.total"]'
    );

    if (totalInput) {
      const oldValue = parseFloat(totalInput.value.replace(/[\$,]/g, "")) || 0;
      totalInput.value = networkRevenue;
      const tolerance = 0.0; // Define your tolerance value here

      if (!isWithinTolerance(oldValue, networkRevenue, tolerance)) {
        highlightInput(totalInput, oldValue, "tolerance");
        return {
          success: false,
          status: "tolerance",
          message: `Tolerance off for Credit Cards: Old Value ${oldValue}, New Value ${networkRevenue}`,
        };
      } else {
        highlightInput(totalInput, oldValue, "success");
        return { success: true };
      }
    } else {
      return {
        success: false,
        message: "Network Revenue input field not found",
      };
    }
  } else {
    return { success: false, message: "Credit Cards row not found" };
  }
}

function fillFuelDiscounts(fuelDiscounts) {
  // Locate the table row that contains the "Total Discounts" field
  const discountRow = Array.from(document.querySelectorAll("td.boldTextStyle"))
    .find((td) => td.textContent.trim() === "Total Discounts")
    ?.closest("tr");

  if (discountRow) {
    // Find the input field within this row
    const totalInput = discountRow.querySelector(
      'input[name="FuelReportFieldReading.total"]'
    );

    if (totalInput) {
      const oldValue = parseFloat(totalInput.value.replace(/[\$,]/g, "")) || 0;
      const positiveFuelDiscounts = Math.abs(fuelDiscounts); // Convert negative to positive
      totalInput.value = positiveFuelDiscounts;
      const tolerance = 0.0; // Define your tolerance value here

      if (!isWithinTolerance(oldValue, positiveFuelDiscounts, tolerance)) {
        highlightInput(totalInput, oldValue, "tolerance");
        return {
          success: false,
          status: "tolerance",
          message: `Tolerance off for Total Discounts: Old Value ${oldValue}, New Value ${positiveFuelDiscounts}`,
        };
      } else {
        highlightInput(totalInput, oldValue, "success");
        return { success: true };
      }
    } else {
      return {
        success: false,
        message: "Total Discounts input field not found",
      };
    }
  } else {
    return { success: false, message: "Total Discounts row not found" };
  }
}

function isWithinTolerance(oldValue, newValue, tolerance = 0.0) {
  return Math.abs(oldValue - newValue) <= tolerance;
}
