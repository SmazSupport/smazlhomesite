import {
  setupDragAndDrop,
  setupFileInput,
  setupCloseButtons,
  updateDropZone,
  appendStatusMessage,
} from "./utils.js";
import { processPDFFile } from "./fuel_report.js";
import { processCsvExcelFile } from "./stick_reading_report.js";

document.addEventListener("DOMContentLoaded", () => {
  console.log("main.js: DOMContentLoaded event triggered");
  init();
});

function init() {
  console.log("Initializing");

  const fileInputFuel = document.getElementById("pdfUpload");
  const dropZoneFuel = document.getElementById("drop_zone");
  const fileInputStick = document.getElementById("csvExcelUpload");
  const dropZoneStick = document.getElementById("drop_zone_stick");
  const autoLoadFuelReport = document.getElementById("autoLoadFuelReport");
  const autoLoadStickReadingReport = document.getElementById(
    "autoLoadStickReadingReport"
  );
  let selectedFile = null;

  if (dropZoneFuel && fileInputFuel) {
    console.log("Setting up fuel report drag and drop");
    setupDragAndDrop(dropZoneFuel, fileInputFuel, handleFileSelectFuel);
    setupFileInput(fileInputFuel, handleFileSelectFuel);
    setupProcessButton("extractText", processPDFFile);
  } else {
    console.log("Fuel report elements not found");
  }

  if (dropZoneStick && fileInputStick) {
    console.log("Setting up stick reading report drag and drop");
    setupDragAndDrop(dropZoneStick, fileInputStick, handleFileSelectStick);
    setupFileInput(fileInputStick, handleFileSelectStick);
    setupProcessButton("processCsvExcel", processCsvExcelFile);
  } else {
    console.log("Stick reading report elements not found");
  }

  if (autoLoadFuelReport) {
    chrome.storage.local.get(["autoLoadFuelReport"], (result) => {
      autoLoadFuelReport.checked = result.autoLoadFuelReport || false;
    });

    autoLoadFuelReport.addEventListener("change", () => {
      chrome.storage.local.set({
        autoLoadFuelReport: autoLoadFuelReport.checked,
      });
    });
  }

  if (autoLoadStickReadingReport) {
    chrome.storage.local.get(["autoLoadStickReadingReport"], (result) => {
      autoLoadStickReadingReport.checked =
        result.autoLoadStickReadingReport || false;
    });

    autoLoadStickReadingReport.addEventListener("change", () => {
      chrome.storage.local.set({
        autoLoadStickReadingReport: autoLoadStickReadingReport.checked,
      });
    });
  }

  setupCloseButtons();

  function handleFileSelectFuel(file) {
    console.log("Handling file select for fuel report", file.name);
    if (file.type !== "application/pdf") {
      appendStatusMessage(
        "Invalid file type. Please upload a PDF file.",
        "error",
        "status-fuel"
      );
      return;
    }
    selectedFile = file;
    updateDropZone(dropZoneFuel, file.name);
    appendStatusMessage(
      'PDF file loaded. Click "Process PDF" to start processing.',
      "info",
      "status-fuel"
    );
  }

  function handleFileSelectStick(file) {
    console.log("Handling file select for stick reading report", file.name);
    if (
      ![
        "text/csv",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      ].includes(file.type)
    ) {
      appendStatusMessage(
        "Invalid file type. Please upload a CSV/Excel file.",
        "error",
        "status-stick"
      );
      return;
    }
    selectedFile = file;
    updateDropZone(dropZoneStick, file.name);
    appendStatusMessage(
      'CSV/Excel file loaded. Click "Process CSV/Excel" to start processing.',
      "info",
      "status-stick"
    );
  }

  function setupProcessButton(buttonId, processFunction) {
    const button = document.getElementById(buttonId);
    if (button) {
      console.log("Setting up process button", buttonId);
      button.addEventListener("click", () => {
        if (!selectedFile) {
          appendStatusMessage(
            "Please select a file first.",
            "error",
            buttonId === "extractText" ? "status-fuel" : "status-stick"
          );
          return;
        }
        console.log("Processing file", selectedFile.name);
        processFunction(selectedFile);
      });
    } else {
      console.log("Process button not found", buttonId);
    }
  }
}
