import { appendStatusMessage } from "./utils.js";

// Dynamically load PapaParse
const script = document.createElement("script");
script.src = chrome.runtime.getURL("papaparse.min.js");
document.head.appendChild(script);

script.onload = function () {
  console.log("PapaParse loaded");
};

export function processCsvExcelFile(file) {
  if (
    ![
      "text/csv",
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ].includes(file.type)
  ) {
    appendStatusMessage(
      "Invalid file type. Please upload a CSV/Excel file.",
      "error",
      "status-stick"
    );
    return;
  }

  const reader = new FileReader();
  reader.onload = function (event) {
    const csvData = event.target.result;
    parseCsvData(csvData);
  };
  reader.readAsText(file);
}

function parseCsvData(csvData) {
  if (typeof Papa !== "undefined") {
    Papa.parse(csvData, {
      header: true,
      skipEmptyLines: true,
      complete: function (results) {
        const data = results.data;
        const extractedData = data.map((row) => {
          const dateTimeString = row["Read Time"];
          const dateTime = parseDateTime(dateTimeString);

          if (!dateTime) {
            console.error(`Invalid Date: ${dateTimeString}`);
          }

          return {
            locationName: row["Location Name"],
            tank: row["Tank"],
            dateTime: dateTime ? dateTime : "Invalid Date",
            timestamp: dateTime ? dateTime.getTime() : null,
            productHeight: row["Product Height (in)"],
          };
        });

        console.log("Extracted Data:", extractedData); // Log the converted CSV data
        displayData(extractedData);
      },
    });
  } else {
    appendStatusMessage(
      "PapaParse is not loaded. Please check the script inclusion.",
      "error",
      "status-stick"
    );
  }
}

function parseDateTime(dateTimeString) {
  // Expected format: MM/DD/YYYY hh:mmam/pm
  const [datePart, timePart] = dateTimeString.split(" ");

  if (!datePart || !timePart) return null;

  const [month, day, year] = datePart.split("/").map(Number);
  let [time, period] = [
    timePart.slice(0, -2),
    timePart.slice(-2).toLowerCase(),
  ];

  if (!month || !day || !year || !time || !period) return null;

  let [hours, minutes] = time.split(":").map(Number);
  if (period === "pm" && hours < 12) hours += 12;
  if (period === "am" && hours === 12) hours = 0;

  const date = new Date(year, month - 1, day, hours, minutes);
  return isNaN(date.getTime()) ? null : date;
}

function displayData(data) {
  const statusElementId = "status-stick";
  const statusElement = document.getElementById(statusElementId);

  let message = "<h3>Stick Reading Report Data</h3><ul>";
  const timestamps = data
    .map((entry) => entry.timestamp)
    .filter((ts) => ts !== null);

  // Remove outliers using IQR
  const filteredTimestamps = removeOutliers(timestamps);

  // Calculate average timestamp
  const averageTimestamp =
    filteredTimestamps.reduce((sum, value) => sum + value, 0) /
    filteredTimestamps.length;
  const averageDate = new Date(averageTimestamp);

  data.forEach((entry) => {
    const timeDiffInMinutes = Math.abs(
      (entry.timestamp - averageTimestamp) / (1000 * 60)
    );
    const isOutlier = timeDiffInMinutes > 60;
    const fontColor = isOutlier ? "red" : "black";

    message += `
      <li style="color: ${fontColor};">
        Location Name: ${entry.locationName}, 
        Tank: ${entry.tank}, 
        Read Date: ${
          entry.dateTime instanceof Date
            ? entry.dateTime.toLocaleDateString()
            : "Invalid Date"
        }, 
        Read Time: ${
          entry.dateTime instanceof Date
            ? entry.dateTime.toLocaleTimeString()
            : "Invalid Date"
        }, 
        Product Height (in): ${entry.productHeight}
      </li>
    `;
  });

  message += "</ul>";

  if (!isNaN(averageTimestamp)) {
    message += `<h3>Average Read Time: ${averageDate.toLocaleDateString()} ${averageDate.toLocaleTimeString()}</h3>`;
  } else {
    message += `<h3>Average Read Time: Invalid Date</h3>`;
  }

  appendStatusMessage(message, "info", statusElementId);
}

function removeOutliers(values) {
  if (values.length < 4) return values;

  values.sort((a, b) => a - b);
  const q1 = values[Math.floor(values.length / 4)];
  const q3 = values[Math.ceil(values.length * (3 / 4))];
  const iqr = q3 - q1;
  const lowerBound = q1 - 1.5 * iqr;
  const upperBound = q3 + 1.5 * iqr;

  return values.filter((value) => value >= lowerBound && value <= upperBound);
}
