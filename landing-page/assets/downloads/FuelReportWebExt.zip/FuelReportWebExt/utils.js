export function setupDragAndDrop(dropZone, fileInput, handleFileSelect) {
  console.log("Setting up drag and drop for", dropZone.id);

  dropZone.addEventListener("click", () => {
    console.log("Drop zone clicked", dropZone.id);
    fileInput.click();
  });

  dropZone.addEventListener("dragover", (event) => {
    event.stopPropagation();
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
  });

  dropZone.addEventListener("drop", (event) => {
    event.stopPropagation();
    event.preventDefault();
    if (event.dataTransfer.files.length) {
      console.log("File dropped in", dropZone.id);
      handleFileSelect(event.dataTransfer.files[0]);
    }
  });
}

export function setupFileInput(fileInput, handleFileSelect) {
  console.log("Setting up file input for", fileInput.id);

  fileInput.addEventListener("change", (event) => {
    if (event.target.files.length) {
      console.log("File selected in", fileInput.id);
      handleFileSelect(event.target.files[0]);
    }
  });
}

export function setupCloseButtons() {
  console.log("Setting up close buttons");

  const closeButtonTop = document.getElementById("close-button");
  const closeButtonFooter = document.getElementById("close-footer-button");

  if (closeButtonTop) {
    closeButtonTop.addEventListener("click", () => {
      console.log("Top close button clicked");
      window.close();
    });
  } else {
    console.log("Top close button not found");
  }

  if (closeButtonFooter) {
    closeButtonFooter.addEventListener("click", () => {
      console.log("Footer close button clicked");
      window.close();
    });
  } else {
    console.log("Footer close button not found");
  }
}

export function updateDropZone(dropZone, fileName) {
  dropZone.textContent = `${fileName} has been uploaded`;
  dropZone.style.background = "#e8e8e8";
  console.log("Updated drop zone", dropZone.id, "with file", fileName);
}

export function appendStatusMessage(
  message,
  messageType = "info",
  statusElementId
) {
  const statusDiv = document.getElementById(statusElementId);
  if (!statusDiv) {
    console.log("Status div not found:", statusElementId);
    return;
  }

  const messagePara = document.createElement("p");
  messagePara.innerHTML = message; // Use innerHTML to support HTML content
  messagePara.classList.add("log-message", `${messageType}-message`);
  statusDiv.appendChild(messagePara);
  statusDiv.scrollTop = statusDiv.scrollHeight;
  console.log("Appended status message to", statusElementId, ":", message);
}
