import { appendStatusMessage } from "./utils.js";

export function processPDFFile(file) {
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    chrome.runtime.getURL("pdf.worker.min.js");

  file
    .arrayBuffer()
    .then((buffer) => {
      const typedarray = new Uint8Array(buffer);
      pdfjsLib
        .getDocument(typedarray)
        .promise.then((pdf) => {
          const promises = Array.from({ length: pdf.numPages }, (_, i) =>
            pdf
              .getPage(i + 1)
              .then((page) =>
                page
                  .getTextContent()
                  .then((textContent) =>
                    textContent.items.map((item) => item.str).join(" ")
                  )
              )
          );

          Promise.all(promises)
            .then((pagesText) => handlePDFText(pagesText, pdf))
            .catch((reason) =>
              handleError(`Error processing PDF pages: ${reason}`, pdf)
            );
        })
        .catch((reason) => handleError(`Error loading PDF: ${reason}`));
    })
    .catch((reason) => handleError(`Error reading file: ${reason}`));
}

function handlePDFText(pagesText, pdf) {
  const finalText = pagesText.join("\n");
  const { data: structuredData, method } = parseFuelData(finalText);
  const networkRevenue = extractNetworkRevenue(finalText);
  const fuelDiscounts = extractFuelDiscounts(finalText);

  if (networkRevenue !== null) {
    chrome.storage.local.set({ networkRevenue }, () =>
      console.log("Network Revenue is set to " + networkRevenue)
    );
  }

  if (fuelDiscounts !== null) {
    chrome.storage.local.set({ fuelDiscounts }, () =>
      console.log("Fuel Discounts is set to " + fuelDiscounts)
    );
  }

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      console.log("Sending message to content script:", structuredData);
      chrome.tabs.sendMessage(
        tabs[0].id,
        { action: "fillForm", data: structuredData },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error(
              `Error sending message: ${chrome.runtime.lastError.message}`
            );
            handleError(
              `Error sending message: ${chrome.runtime.lastError.message}`,
              pdf
            );
          } else {
            console.log("Response received from content script:", response);
            handleResponse(response);
          }
          pdf.destroy(); // Ensure the PDF is destroyed after processing
        }
      );
    } else {
      console.error("No active tab found");
      handleError("No active tab found", pdf);
    }
  });
}

function handleResponse(response) {
  console.log("Response received", response);

  if (!response) {
    appendStatusMessage(
      "No response received from content script.",
      "error",
      "status-fuel"
    );
    return;
  }

  if (response.type === "warning" && Array.isArray(response.messages)) {
    response.messages.forEach((msg) =>
      appendStatusMessage(msg, "warning", "status-fuel")
    );
  } else if (response.type) {
    appendStatusMessage(response.message, response.type, "status-fuel");
  } else {
    appendStatusMessage("Unexpected response format.", "error", "status-fuel");
  }
}

function handleError(message, pdf = null) {
  appendStatusMessage(message, "error", "status-fuel");
  if (pdf) pdf.destroy(); // Ensure the PDF is destroyed if defined
}

function parseFuelData(text) {
  const fallbackData = extractUsingFallbackMethod(text);
  return { data: fallbackData, method: "fallback" };
}

function extractFuelDiscounts(text) {
  console.log("Full text for processing:", text);

  // Define the start and end section patterns
  const startPattern = /Fuel\s+Sales\s+Grade\s+Grade\s+Name\s+Volume/;
  const endPattern = /Total\s+Sales/;

  // Find the start and end indexes using regular expressions
  const startMatch = text.match(startPattern);
  const endMatch = text.match(endPattern);

  if (!startMatch || !endMatch) {
    console.error("Relevant section not found in the text");
    return null;
  }

  const startIndex = startMatch.index;
  const endIndex = endMatch.index;

  // Extract the relevant section
  const sectionText = text.substring(startIndex, endIndex);
  console.log("Extracted section for Fuel Discounts:", sectionText);

  // Define the regex to find the Fuel Discounts value
  const regex = /Fuel\s+Discounts\s+(-?\$?\d{1,3}(,\d{3})*(\.\d{2})?)/;
  const match = sectionText.match(regex);

  if (match && match[1]) {
    const fuelDiscounts = parseFloat(
      match[1].replace(/,/g, "").replace("$", "")
    );
    console.log("Extracted Fuel Discounts:", fuelDiscounts);
    return fuelDiscounts;
  } else {
    console.error(
      "Fuel Discounts not found in the specified section of the text"
    );
    return null;
  }
}

function extractNetworkRevenue(text) {
  const regex = /Network Revenue\s+\$(\d{1,3}(,\d{3})*(\.\d{2})?)/;
  const match = text.match(regex);
  return match && match[1] ? parseFloat(match[1].replace(/,/g, "")) : null;
}

function extractUsingFallbackMethod(text) {
  const gradeMap = getGradeMapping();
  const gradeRegex = getGradeRegex(gradeMap);
  const relevantText = extractRelevantText(
    text,
    "Pump Totals Report",
    "Grand Total"
  );

  return relevantText
    .split(/Fueling Position\s+\d+/)
    .slice(1)
    .map(parsePositionText)
    .flat()
    .filter(Boolean);

  function parsePositionText(pos, index) {
    const positionNumber = index + 1;
    return pos
      .trim()
      .split(gradeRegex)
      .slice(1)
      .reduce((acc, segment, i, arr) => {
        if (i % 2 === 0) {
          const gradeKey = segment.trim();
          const gradeName = gradeMap[gradeKey.toUpperCase()] || gradeKey;
          if (gradeName !== "Ignore") {
            const values = arr[i + 1]
              .trim()
              .split(/\s+/)
              .map((val) => parseFloat(val.replace(/[\$,]/g, "")));
            if (values.length >= 6 && values.every((val) => !isNaN(val))) {
              acc.push({
                "Fueling Position": positionNumber,
                "Grade Name": gradeName,
                "Close Money": values[0],
                "Open Money": values[1],
                "Close Volume": values[3],
                "Open Volume": values[4],
              });
            }
          }
        }
        return acc;
      }, []);
  }
}

function extractRelevantText(text, startMarker, endMarker) {
  const startIndex = text.indexOf(startMarker);
  const endIndex = text.indexOf(endMarker, startIndex);
  return text
    .substring(startIndex, endIndex)
    .replace(/Page\s+\d+\s+of\s+\d+/g, "");
}

function getGradeRegex(gradeMap) {
  const escapedGrades = Object.keys(gradeMap)
    .map(escapeRegex)
    .sort((a, b) => b.length - a.length);
  return new RegExp(`(${escapedGrades.join("|")})`, "gi");
}

function escapeRegex(string) {
  return string.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
}

function getGradeMapping() {
  return {
    REGULAR: "Unleaded",
    UNLEADED: "Unleaded",
    REGULAR2: "Unleaded",
    REGULAR1: "Unleaded",
    "PLUS-EXTRA": "Plus",
    PLUS: "Plus",
    PLUS2: "Plus",
    PLUS1: "Plus",
    "MID-GRADE": "Plus",
    "SUPREME-+": "Super",
    SUPER: "Super",
    SUPER1: "Super",
    SUPER2: "Super",
    PREMIUM: "Super",
    PREMIUM1: "Super",
    PREMIUM2: "Super",
    VPOWER: "Super",
    "DIESEL 1": "Diesel",
    DIESEL: "Diesel",
    TOTAL: "Ignore",
  };
}
