chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id && tab.url && tab.url.startsWith("http")) {
        injectContentScript(tab.id);
      }
    });
  });
});

function injectContentScript(tabId, retries = 0) {
  chrome.scripting
    .executeScript({
      target: { tabId: tabId },
      files: ["content.js"],
    })
    .then(() => {
      console.log(`Content script injected into tab ${tabId}`);
    })
    .catch((error) => {
      console.error(`Failed to inject script into tab ${tabId}: ${error}`);
      if (retries < 3) {
        // Retry up to 3 times
        setTimeout(
          () => injectContentScript(tabId, retries + 1),
          1000 * (retries + 1)
        ); // Exponential back-off
      } else {
        notifyUser(
          `Script injection failed for tab ${tabId}. Please check permissions.`
        );
      }
    });
}

function notifyUser(message) {
  chrome.notifications.create(
    "",
    {
      type: "basic",
      iconUrl: "images/icon48.png",
      title: "Extension Notification",
      message: message,
    },
    (notificationId) => {
      // Optional: Handle notification events if necessary
    }
  );
}
